package com.example.bmr_lab;

import static java.lang.Integer.parseInt;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.Spinner;

public class MainActivity extends AppCompatActivity {

    public static final String BMI_MSG = "com.example.bmi.MainActivity";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Spinner spinner = findViewById(R.id.spinner);
        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this,
                R.array.Exerciselist, android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner.setAdapter(adapter);
    }

    public void calculate(View view) {
        Intent intent = new Intent(MainActivity.this, BMR.class);

        EditText ageEditText;
        ageEditText = findViewById(R.id.Age);
        EditText heightEditText;
        heightEditText = findViewById(R.id.Height);
        EditText weightEditText;
        weightEditText = findViewById(R.id.Weight);

        int age = parseInt(ageEditText.getText().toString());
        int height = parseInt((heightEditText.getText().toString()));
        int weight = parseInt(weightEditText.getText().toString());

        double result = ((10 * weight) + (6.25 * height) + (5 * age));

        RadioButton male_radiobutton = findViewById(R.id.radio1);
        RadioButton female_radiobutton = findViewById(R.id.radio2);

        if(male_radiobutton.isChecked()){
            result += 5;
        }else if (female_radiobutton.isChecked()){
            result -= 161;
        }
        Spinner spinner = findViewById(R.id.spinner);

        int id = (int) spinner.getSelectedItemId();

        switch (id){
            case 0 :
                result = 1.2 * result;
                break;
            case 1 :
                result = 1.375 * result;
                break;
            case 2 :
                result = 1.55 * result;
                break;
            case 3 :
                result = 1.725 * result;
                break;
            case 4 :
                result = 1.9 * result;
                break;
        }
        intent.putExtra(BMI_MSG,String.format("%.2f",result));
        startActivity(intent);
    }
}