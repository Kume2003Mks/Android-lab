package com.example.exchangerate;


public class Exrate {
    private String text_ratecer;
    private String cer_set;
    private double exrate;

    public Exrate(String text_cer,String cer_set) {
        this.text_ratecer = text_cer;
        this.cer_set = cer_set;
    }
    @Override
    public String toString() {

        return text_ratecer;
    }

    public String getCer_set() {
        return cer_set;
    }


}